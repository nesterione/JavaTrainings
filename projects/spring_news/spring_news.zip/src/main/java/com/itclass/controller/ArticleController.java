package com.itclass.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("article")
public class ArticleController {

	
	
	@RequestMapping("all")
	public String showAll(Model model) {
		return "index";
	}
}